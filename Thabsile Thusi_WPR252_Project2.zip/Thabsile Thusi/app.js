let express = require("express");
let { Home, Contact, Process } = require("./functions");
let webServer = express();
let bodyParser = require("body-parser"); // We are creating a variable called bodyParser

//
webServer.set("view engine", "ejs"); // set the application to use EJS
webServer.use(express.static("public")); //To set the public folder
webServer.use(bodyParser.urlencoded({ extended: true })); //

//Primary
webServer.get("/", Home);
webServer.get("/contact", Contact);
webServer.post("/process", (request, response) => {
  let name = request.body.firstName;
  response.send("The name is: " + name);
});

//404 Page
webServer.use((request, response) => {
  response.send("<h1 style='text-align:center'>404: Page not found</h1>");
});
//

const port = 8112;
const host = "localhost";

webServer.listen(port, host, () => {
  console.log("The server is running on http://" + host + ":" + port);

  console.log(`The server is running on http://${host}:${port}`);
});
